<template>
  <div class="em-data-type-expand">
    <p><pre>{{data}}</pre></p>
  </div>
</template>

<script>
export default {
  props: {
    data: {}
  }
}
</script>
